import { Component } from '@angular/core';

@Component({
  selector: 'app-apphome',
  standalone: false,
  templateUrl: './apphome.component.html',
  styleUrl: './apphome.component.css'
})
export class ApphomeComponent {

}
