export class Student{
   
    sid?:number;
    sname:string='';
    emailId:string='';
    address: string='';
    contact:string='';
    department:string='';
student: any;
    

}